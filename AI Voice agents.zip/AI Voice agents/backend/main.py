
from pathlib import Path
from contextlib import contextmanager
from datetime import datetime, timezone
from decimal import Decimal
import sqlite3
import uuid
import re

import chromadb
from fastapi import FastAPI, HTTPException, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from sentence_transformers import SentenceTransformer


# =====================================================
# 1. LOCAL FILE STORAGE
# =====================================================

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
DOCS = DATA / "docs"
RECORDINGS = DATA / "recordings"
DB = DATA / "invoices.sqlite3"

for folder in [DATA, DOCS, RECORDINGS]:
    folder.mkdir(parents=True, exist_ok=True)


# =====================================================
# 2. FASTAPI APPLICATION
# =====================================================

app = FastAPI(
    title="Local AI Invoice Agent",
    description="ElevenLabs + FastAPI + SQLite + ChromaDB RAG",
    version="1.1.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173"
    ],
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["Content-Type"]
)


# =====================================================
# 3. SQLITE CONNECTION
# =====================================================

@contextmanager
def connection():
    db = sqlite3.connect(DB)
    db.row_factory = sqlite3.Row

    try:
        db.execute("PRAGMA foreign_keys = ON")
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


# =====================================================
# 4. INITIALIZE LOCAL DATABASE
# =====================================================

def init_db():
    with connection() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS customers (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS invoices (
            id TEXT PRIMARY KEY,
            customer_id TEXT NOT NULL,
            amount_minor INTEGER NOT NULL,
            currency TEXT NOT NULL,
            status TEXT NOT NULL,
            due_date TEXT NOT NULL,
            FOREIGN KEY(customer_id) REFERENCES customers(id)
        );

        CREATE TABLE IF NOT EXISTS audit (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL,
            action TEXT NOT NULL,
            reference TEXT
        );
        """)

        # Keep existing demo records for compatibility.
        db.execute(
            "INSERT OR IGNORE INTO customers (id, name) VALUES (?, ?)",
            ("CUST-DEMO", "Demo Customer")
        )

        db.execute(
            """
            INSERT OR IGNORE INTO invoices
            (id, customer_id, amount_minor, currency, status, due_date)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                "INV-1001",
                "CUST-DEMO",
                125000,
                "INR",
                "unpaid",
                "2026-12-15"
            )
        )


init_db()


# =====================================================
# 5. CUSTOMER ID NORMALIZATION
# =====================================================

# Maps easy-to-speak numeric IDs to the existing
# customer IDs already stored in the demo database.
#
# IMPORTANT:
# This is a lookup alias, NOT authentication.

CUSTOMER_ID_ALIASES = {
    "1001": "CUST-DEMO"
}


def normalize_customer_id(customer_id: str) -> str:
    """
    Convert numeric demo IDs into existing DB IDs.

    Examples:
      1001       -> CUST-DEMO
      "1 0 0 1"  -> CUST-DEMO
      CUST-DEMO  -> CUST-DEMO

    Other IDs are preserved rather than guessed.
    """

    value = customer_id.strip().upper()

    # Remove spaces between spoken digits.
    compact = re.sub(r"\s+", "", value)

    # Allow basic spoken-format separators.
    if re.fullmatch(r"[0-9 -]+", compact):
        digits = re.sub(r"\D", "", compact)

        if digits in CUSTOMER_ID_ALIASES:
            return CUSTOMER_ID_ALIASES[digits]

        return digits

    return compact


def normalize_invoice_id(invoice_id: str) -> str:
    """
    Normalize basic invoice formatting.

    Examples:
      inv-1001 -> INV-1001
      INV 1001 -> INV-1001
      1001     -> INV-1001

    This is only used for invoice lookup.
    """

    value = invoice_id.strip().upper()

    value = re.sub(r"\s+", "", value)

    if value.isdigit():
        return f"INV-{value}"

    match = re.fullmatch(r"INV-?(\d+)", value)

    if match:
        return f"INV-{match.group(1)}"

    return value


# =====================================================
# 6. LOCAL RAG SYSTEM
# =====================================================

# First run downloads the embedding model.
# Subsequent runs use the locally cached model.

model = SentenceTransformer(
    "sentence-transformers/all-MiniLM-L6-v2"
)

client = chromadb.PersistentClient(
    path=str(DATA / "chroma")
)

collection = client.get_or_create_collection(
    name="invoice_policies"
)


# =====================================================
# 7. REQUEST MODELS
# =====================================================

class SearchRequest(BaseModel):
    question: str = Field(
        min_length=2,
        max_length=1000
    )


class InvoiceRequest(BaseModel):
    invoice_id: str = Field(
        min_length=1,
        max_length=80
    )

    # Demo-only caller supplied ID.
    # Real systems must use authenticated identity.
    customer_id: str = Field(
        min_length=1,
        max_length=80
    )


# =====================================================
# 8. HEALTH CHECK
# =====================================================

@app.get("/health")
def health():
    return {
        "status": "ok",
        "database": "SQLite",
        "rag": "ChromaDB",
        "indexed_documents": collection.count(),
        "local_db": str(DB)
    }


# =====================================================
# 9. GET INVOICE TOOL
# =====================================================

@app.post("/tools/get_invoice")
def get_invoice(request: InvoiceRequest):

    invoice_id = normalize_invoice_id(
        request.invoice_id
    )

    customer_id = normalize_customer_id(
        request.customer_id
    )

    print(
        f"[GET INVOICE] invoice={invoice_id}, "
        f"customer={customer_id}"
    )

    with connection() as db:

        row = db.execute(
            """
            SELECT
                id,
                customer_id,
                amount_minor,
                currency,
                status,
                due_date
            FROM invoices
            WHERE id = ?
              AND customer_id = ?
            """,
            (
                invoice_id,
                customer_id
            )
        ).fetchone()

        if not row:
            raise HTTPException(
                status_code=404,
                detail=(
                    "Invoice not found for this customer. "
                    "Please verify the invoice and customer IDs."
                )
            )

        db.execute(
            """
            INSERT INTO audit
            (created_at, action, reference)
            VALUES (?, ?, ?)
            """,
            (
                datetime.now(timezone.utc).isoformat(),
                "get_invoice",
                invoice_id
            )
        )

        invoice = dict(row)

        amount_minor = invoice.pop("amount_minor")

        invoice["amount"] = str(
            Decimal(amount_minor) / Decimal(100)
        )

        invoice["amount"] = (
            f"{Decimal(invoice['amount']):.2f}"
        )

        # Return the numeric alias where available.
        invoice["customer_id"] = request.customer_id.strip()

        return invoice


# =====================================================
# 10. SEARCH KNOWLEDGE TOOL (LOCAL RAG)
# =====================================================

@app.post("/tools/search_knowledge")
def search_knowledge(request: SearchRequest):

    print(
        "[RAG SEARCH]",
        request.question
    )

    if collection.count() == 0:
        return {
            "matches": [],
            "message": (
                "No documents indexed yet. "
                "Run python ingest.py first."
            )
        }

    embedding = model.encode(
        request.question
    ).tolist()

    results = collection.query(
        query_embeddings=[embedding],
        n_results=min(3, collection.count())
    )

    matches = []

    documents = results["documents"][0]
    metadatas = results["metadatas"][0]
    distances = results["distances"][0]

    for document, metadata, distance in zip(
        documents,
        metadatas,
        distances
    ):
        matches.append({
            "source": (metadata or {}).get(
                "source",
                "unknown"
            ),
            "text": document,
            "distance": float(distance)
        })

    return {
        "question": request.question,
        "matches": matches,
        "total_matches": len(matches)
    }


# =====================================================
# 11. SAVE LOCAL MICROPHONE RECORDINGS
# =====================================================

@app.post("/recordings")
async def save_recording(
    audio: UploadFile = File(...)
):

    allowed_types = {
        "audio/webm": ".webm",
        "audio/ogg": ".ogg",
        "audio/mp4": ".mp4"
    }

    if audio.content_type not in allowed_types:
        raise HTTPException(
            status_code=415,
            detail="Unsupported audio format"
        )

    content = await audio.read(20_000_001)

    if len(content) > 20_000_000:
        raise HTTPException(
            status_code=413,
            detail="Recording is too large"
        )

    extension = allowed_types[
        audio.content_type
    ]

    filename = (
        f"{uuid.uuid4().hex}{extension}"
    )

    filepath = RECORDINGS / filename

    filepath.write_bytes(content)

    return {
        "saved": True,
        "filename": filename,
        "storage": "local"
    }
