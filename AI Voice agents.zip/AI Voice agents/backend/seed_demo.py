"""Idempotently load synthetic customers, invoices and payments into the existing local SQLite database."""
from pathlib import Path
import json,sqlite3
ROOT=Path(__file__).parent
DATA=ROOT/'data'
def read(name):
    return json.loads((DATA/'sample_data'/name).read_text(encoding='utf-8'))
with sqlite3.connect(DATA/'invoices.sqlite3') as db:
    db.execute('PRAGMA foreign_keys=ON')
    db.executescript("""
    CREATE TABLE IF NOT EXISTS customers (id TEXT PRIMARY KEY, name TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS invoices (id TEXT PRIMARY KEY, customer_id TEXT NOT NULL, amount_minor INTEGER NOT NULL, currency TEXT NOT NULL, status TEXT NOT NULL, due_date TEXT NOT NULL, FOREIGN KEY(customer_id) REFERENCES customers(id));
    CREATE TABLE IF NOT EXISTS demo_invoice_details (invoice_id TEXT PRIMARY KEY, issue_date TEXT NOT NULL, description TEXT NOT NULL, balance_minor INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS demo_payments (payment_id TEXT PRIMARY KEY, invoice_id TEXT NOT NULL, amount_minor INTEGER NOT NULL, paid_on TEXT NOT NULL, method TEXT NOT NULL, reference TEXT NOT NULL);
    """)
    for customer in read('customers.json'):
        db.execute('INSERT OR IGNORE INTO customers(id,name) VALUES (?,?)',(customer['customer_id'],customer['name']))
    for inv in read('invoices.json'):
        db.execute('INSERT OR IGNORE INTO invoices(id,customer_id,amount_minor,currency,status,due_date) VALUES (?,?,?,?,?,?)',(inv['invoice_id'],inv['customer_id'],inv['total_minor'],inv['currency'],inv['status'],inv['due_date']))
        db.execute('INSERT OR REPLACE INTO demo_invoice_details VALUES (?,?,?,?)',(inv['invoice_id'],inv['issue_date'],inv['description'],inv['balance_minor']))
    for payment in read('payments.json'):
        db.execute('INSERT OR IGNORE INTO demo_payments VALUES (?,?,?,?,?,?)',(payment['payment_id'],payment['invoice_id'],payment['amount_minor'],payment['paid_on'],payment['method'],payment['reference']))
    db.commit()
print('Synthetic demo loaded: 12 customers, 48 invoices, payment records.')
