from pathlib import Path
from main import DOCS, collection, model

supported = list(DOCS.glob('*.txt')) + list(DOCS.glob('*.md'))
if not supported:
    print('Add .txt or .md documents into backend/data/docs/ first.')
for path in supported:
    content = path.read_text(encoding='utf-8')
    # Small starter chunking with overlap; replace with semantic section splitter later.
    chunks = []
    for start in range(0, len(content), 700):
        chunk = content[max(0, start - 100):start + 700].strip()
        if chunk:
            chunks.append(chunk)
    if chunks:
        vectors = model.encode(chunks).tolist()
        ids = [f'{path.name}:{i}' for i in range(len(chunks))]
        collection.upsert(ids=ids, embeddings=vectors, documents=chunks,
                          metadatas=[{'source': path.name}] * len(chunks))
        print(f'Indexed {path.name}: {len(chunks)} chunks')
