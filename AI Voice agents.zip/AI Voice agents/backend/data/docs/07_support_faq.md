# Billing support frequently asked questions (DEMO FAQ)
Q: Where is my invoice? A: After authentication, give the invoice number to the agent; the agent uses get_invoice for exact details.
Q: Can I pay in installments? A: Installment arrangements require manual billing-team approval and are not guaranteed.
Q: Can the assistant change my due date? A: No, an authorized team member must approve any extension.
Q: Do I get a receipt? A: A receipt can be prepared after a payment is verified in the ledger.
Q: Can the agent tell me someone else's balance? A: No.
Q: How do I contact support? A: Use the billing support channel provided by the organization; no real email or phone is assigned in this fictional demo.
