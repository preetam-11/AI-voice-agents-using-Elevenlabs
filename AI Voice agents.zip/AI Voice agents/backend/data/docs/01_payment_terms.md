# Billing and payment terms (DEMO POLICY)
Version: 1.0 | Effective: 2026-11-01 | Fictional organization: Acme Billing Demo

Invoices are issued in Indian rupees (INR) and default to net 30 days from the issue date unless the individual invoice says otherwise. The due date printed on the invoice takes precedence. Accepted example methods are UPI, bank transfer and card, but payment instructions must be verified through an authenticated account, not supplied by the voice agent from memory.

A payment is treated as received only when the ledger confirms it. Do not claim a payment has settled based on a customer's spoken statement. The invoice endpoint is authoritative for amount due and status.
