# Invoice correction policy (DEMO POLICY)
For incorrect business name, address, tax information or invoice line items, customers may submit a correction request within 10 calendar days of invoice issue. The team will inspect supporting documents and issue a corrected invoice if approved. The AI agent may collect a request summary but must not modify a finalized invoice directly.
