# Synthetic invoice dataset — instructions

Everything here is fictional. No personal or financial data from real people is included.

## Contents
- `backend/data/docs/`: 8 billing policy and FAQ Markdown files for RAG. `python ingest.py` indexes these files.
- `backend/data/sample_data/`: 12 customers, 48 invoices, and simulated payments in JSON and CSV.
- `backend/data/sample_invoices/`: 15 readable sample invoice documents for inspection only. These are NOT indexed into the shared policy collection to avoid cross-customer disclosure.
- `backend/seed_demo.py`: imports structured data into the starter application's SQLite database.

## Run in order (from backend/)
1. Install dependencies: `pip install -r requirements.txt`
2. Seed structured data: `python seed_demo.py`
3. Build the RAG vector index: `python ingest.py`
4. Start server: `uvicorn main:app --host 127.0.0.1 --port 8000 --reload`
5. Open http://127.0.0.1:8000/docs

### Example requests
`POST /tools/get_invoice` with `{"invoice_id":"INV-1001","customer_id":"CUST-DEMO"}`
`POST /tools/search_knowledge` with `{"question":"What should I do if my payment is not reflected?"}`

The existing demo invoice tool exposes total and status only; payment detail and partial balances are in separate demo SQLite tables for later development. The original starter API does not authenticate real customers: use FICTIONAL DATA ONLY. Its recordings endpoint captures optional browser microphone clips, not the entire two-way ElevenLabs conversation.

**Privacy warning:** A policy RAG index shared among callers must never include private invoices unless retrieval is authorization-filtered. ElevenLabs conversations remain cloud-processed even though the app and local datasets are local.
