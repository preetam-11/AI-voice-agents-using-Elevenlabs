# AI Invoice Agent — local-first starter

This is a development prototype, **not a production billing application**. ElevenLabs processes voice and any tool result returned to the voice agent in the cloud. Invoices, retrieval indexes, and captured microphone recordings are stored on the local computer. Microphone recordings are NOT complete two-way call recordings.

## Requirements
- Python 3.11+ recommended
- Node.js with npm
- An ElevenLabs Conversational Agent ID, and an internet connection for voice service

## Run backend
```bash
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python ingest.py
uvicorn main:app --host 127.0.0.1 --port 8000 --reload
```
Model weights download the first time, then are cached locally.

Try API docs: http://127.0.0.1:8000/docs

Test invoice: POST /tools/get_invoice with `{"invoice_id":"INV-1001","customer_id":"CUST-DEMO"}`
Test RAG: POST /tools/search_knowledge with `{"question":"What happens if a payment is not reflected?"}`

## Configure ElevenLabs
Create a conversational agent and two **Client** tools (not server webhook tools). Turn on **Wait for response** for both:

1. `get_invoice`: required string parameters `invoice_id` and `customer_id`. Description: Retrieve invoice details for the verified customer from the local application. Never guess invoice values.
2. `search_knowledge`: required string parameter `question`. Description: Retrieve invoice and payment policy excerpts from local documents before answering a policy question.

Suggested system prompt:
```
You are a billing assistance agent. Use get_invoice for exact invoice facts and
search_knowledge for policies. Do not invent amounts, payment statuses,
due dates or refund policies. Politely indicate when no result is found.
Never reveal another customer's information. You cannot update payments,
issue refunds, or change invoices. For this demo, use only synthetic data.
```

This starter trusts the `customer_id` supplied by the client and does **not** verify identity. Do not deploy with real customer information; replace it with authenticated customer identity on the backend and apply authorization checks.

## Run frontend
```bash
cd frontend
npm install
cp .env.example .env
# Edit .env, setting your actual agent ID (on Windows copy manually if cp is unavailable).
npm run dev
```
Open http://127.0.0.1:5173 in your browser and permit microphone access.

## Local files
- `backend/data/invoices.sqlite3`: structured invoices and audit records
- `backend/data/chroma/`: vector index
- `backend/data/docs/`: text/markdown policy source docs
- `backend/data/recordings/`: optional captured microphone-only recordings

## Next requirements
Authenticated customer sessions, proper consent and encryption, secret handling, role-based access, recording retention/deletion, robust PDF ingestion, customer-specific RAG permissions, approved financial write actions, automated tests and backups.
