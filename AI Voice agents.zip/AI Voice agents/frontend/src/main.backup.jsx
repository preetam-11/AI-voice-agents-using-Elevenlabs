
function App() {
  const clientTools = {
    get_invoice: async ({ invoice_id, customer_id }) => {
      console.log("GET INVOICE CALLED:", invoice_id, customer_id);

      try {
        const result = await post("/tools/get_invoice", {
          invoice_id,
          customer_id
        });

        console.log("INVOICE RESULT:", result);
        return result;
      } catch (error) {
        console.error("INVOICE ERROR:", error);
        return { error: String(error.message || error) };
      }
    },

    search_knowledge: async ({ question }) => {
      console.log("RAG SEARCH CALLED:", question);

      try {
        const result = await post("/tools/search_knowledge", {
          question
        });

        console.log("RAG RESULT:", result);
        return result;
      } catch (error) {
        console.error("RAG ERROR:", error);
        return { error: String(error.message || error) };
      }
    }
  };

  return (
    <ConversationProvider clientTools={clientTools}>
      <VoicePanel />
    </ConversationProvider>
  );
}

createRoot(document.getElementById("root")).render(
  <App />
);
