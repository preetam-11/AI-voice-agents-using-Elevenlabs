
import React, { useState } from "react";
import { createRoot } from "react-dom/client";

import {
  ConversationProvider,
  useConversationControls,
  useConversationStatus,
  useConversationClientTool
} from "@elevenlabs/react";

const API = "http://127.0.0.1:8000";
const AGENT_ID = import.meta.env.VITE_ELEVENLABS_AGENT_ID;

// Send requests to the local FastAPI server
async function post(path, payload) {
  const response = await fetch(`${API}${path}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(payload)
  });

  const text = await response.text();
  let result;

  try {
    result = JSON.parse(text);
  } catch {
    throw new Error(`Invalid API response: ${text.slice(0, 150)}`);
  }

  if (!response.ok) {
    throw new Error(
      typeof result.detail === "string"
        ? result.detail
        : JSON.stringify(result.detail || result)
    );
  }

  return result;
}

function InvoiceAgent() {
  const { startSession, endSession } = useConversationControls();
  const { status } = useConversationStatus();

  const [message, setMessage] = useState("Ready to connect");
  const [lastTool, setLastTool] = useState("None");
  const [lastResult, setLastResult] = useState(null);
  const [busy, setBusy] = useState(false);

  // TOOL 1: Fetch invoice data
  useConversationClientTool("get_invoice", async (params) => {
    console.log("GET INVOICE CALLED:", params);
    setLastTool("get_invoice");

    try {
      const result = await post("/tools/get_invoice", {
        invoice_id: params.invoice_id,
        customer_id: params.customer_id
      });

      console.log("INVOICE RESULT:", result);
      setLastResult(result);

      return JSON.stringify(result);
    } catch (error) {
      console.error("GET INVOICE ERROR:", error);
      setLastResult({ error: error.message });

      return JSON.stringify({
        error: "Invoice lookup failed",
        message: error.message
      });
    }
  });

  // TOOL 2: Search local RAG knowledge base
  useConversationClientTool("search_knowledge", async (params) => {
    console.log("RAG SEARCH CALLED:", params);
    setLastTool("search_knowledge");

    try {
      const result = await post("/tools/search_knowledge", {
        question: params.question
      });

      console.log("RAG RESULT:", result);
      setLastResult(result);

      return JSON.stringify(result);
    } catch (error) {
      console.error("RAG SEARCH ERROR:", error);
      setLastResult({ error: error.message });

      return JSON.stringify({
        error: "Knowledge search failed",
        message: error.message
      });
    }
  });

  async function start() {
    setBusy(true);

    try {
      if (!AGENT_ID) {
        throw new Error(
          "Missing VITE_ELEVENLABS_AGENT_ID in frontend/.env"
        );
      }

      await navigator.mediaDevices.getUserMedia({
        audio: true
      }).then(stream => {
        stream.getTracks().forEach(track => track.stop());
      });

      await startSession({
        agentId: AGENT_ID
      });

      setMessage("Voice conversation connected");
    } catch (error) {
      console.error("Connection error:", error);
      setMessage(`Error: ${error.message || error}`);
    } finally {
      setBusy(false);
    }
  }

  async function stop() {
    setBusy(true);

    try {
      await endSession();
      setMessage("Conversation ended");
    } catch (error) {
      setMessage(`Error: ${error.message || error}`);
    } finally {
      setBusy(false);
    }
  }

  // Test backend independently of ElevenLabs
  async function testInvoice() {
    setLastTool("Manual invoice test");

    try {
      const result = await post("/tools/get_invoice", {
        invoice_id: "INV-1001",
        customer_id: "CUST-DEMO"
      });

      setLastResult(result);
      setMessage("Invoice API test completed");
    } catch (error) {
      setLastResult({ error: error.message });
      setMessage("Invoice API test failed");
    }
  }

  async function testRag() {
    setLastTool("Manual RAG test");

    try {
      const result = await post("/tools/search_knowledge", {
        question: "What are the payment terms?"
      });

      setLastResult(result);
      setMessage("RAG API test completed");
    } catch (error) {
      setLastResult({ error: error.message });
      setMessage("RAG API test failed");
    }
  }

  const connected = status === "connected";

  return (
    <main style={{
      fontFamily: "Arial, sans-serif",
      maxWidth: 760,
      margin: "50px auto",
      padding: 24,
      color: "#1f2937"
    }}>
      <h1>AI Invoice Agent</h1>
      <p>ElevenLabs Voice + Local RAG + SQLite</p>

      <section style={{
        padding: 24,
        border: "1px solid #ddd",
        borderRadius: 12,
        marginTop: 24
      }}>
        <h2>Voice Assistant</h2>

        <p>
          Connection status: <strong>{status}</strong>
        </p>

        <p>{message}</p>

        <button
          onClick={connected ? stop : start}
          disabled={busy}
          style={{
            padding: "14px 24px",
            cursor: "pointer",
            background: connected ? "#dc2626" : "#2563eb",
            color: "white",
            border: "none",
            borderRadius: 8
          }}
        >
          {busy
            ? "Please wait..."
            : connected
              ? "End Conversation"
              : "Start Voice Conversation"}
        </button>
      </section>

      <section style={{
        padding: 24,
        border: "1px solid #ddd",
        borderRadius: 12,
        marginTop: 20
      }}>
        <h2>Test Local Tools</h2>

        <button onClick={testInvoice}>
          Test Invoice Database
        </button>

        <button
          onClick={testRag}
          style={{ marginLeft: 12 }}
        >
          Test RAG
        </button>

        <h3>Last Tool: {lastTool}</h3>

        <pre style={{
          background: "#f3f4f6",
          padding: 16,
          borderRadius: 8,
          overflowX: "auto",
          whiteSpace: "pre-wrap",
          overflowWrap: "anywhere"
        }}>
          {lastResult
            ? JSON.stringify(lastResult, null, 2)
            : "No tool executed yet"}
        </pre>
      </section>

      <p style={{ fontSize: 12, color: "#666" }}>
        Demo environment. Use synthetic invoice data only.
        Real customer access requires backend authentication.
      </p>
    </main>
  );
}

function App() {
  return (
    <ConversationProvider
      onConnect={() => console.log("ElevenLabs connected")}
      onDisconnect={() => console.log("ElevenLabs disconnected")}
      onError={(error) => console.error("ElevenLabs error:", error)}
    >
      <InvoiceAgent />
    </ConversationProvider>
  );
}

createRoot(document.getElementById("root")).render(
  <App />
);
